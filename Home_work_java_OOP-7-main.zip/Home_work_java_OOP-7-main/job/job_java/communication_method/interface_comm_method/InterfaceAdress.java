package job_java.communication_method.interface_comm_method;

public interface InterfaceAdress {
    public void adressMethod();
    
}
