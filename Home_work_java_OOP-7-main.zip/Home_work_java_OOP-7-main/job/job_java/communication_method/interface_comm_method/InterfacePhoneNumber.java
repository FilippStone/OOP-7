package job_java.communication_method.interface_comm_method;

public interface InterfacePhoneNumber {
    public void phoneNumberMethod();
}
