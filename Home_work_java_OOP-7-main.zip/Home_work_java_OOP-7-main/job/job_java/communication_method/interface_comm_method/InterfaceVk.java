package job_java.communication_method.interface_comm_method;

public interface InterfaceVk {
    public void vkMethod();
}
