package job_java.contragent;

public abstract class AbstractContrAgent {

    protected String name;
    protected int age;
    protected String nameCompany;
    
}
