package job_java.control_list_contragent;

public abstract class AbstractControlContrAgent {

    public void printListContrAgent() {
    };

    public void serchContrAgent() {
    };

    public void addNewContrAgent(){
    };

    public void deleteContrAgent(){
    };

    public void addNewComminicationMethod(){
    };

    public void deleteNewComminicationMethod(){
    };    
}