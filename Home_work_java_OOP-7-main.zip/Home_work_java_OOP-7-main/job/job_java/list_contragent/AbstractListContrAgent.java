package job_java.list_contragent;

import java.util.ArrayList;
import java.util.List;

public class AbstractListContrAgent<T> {
    protected List<T> list = new ArrayList<>();
}
